Cambios implentados para la transformación del programa de bat a PowerShell:

1.- Se reemplazó el @echo off por Clear-Host; comando de PowerShell que quita el texto en la pantalla actual.
2.- El comando $host.UI.RawUI.WindowTitle para mostrar el titulo en lugar del comando title.
3.- Cls eliminado
4.- Se reemplazó el comando color por el $host.UI.RawUI.ForegroundColor que da color al texto
5.- Los comando echo para mostrar texto en PowerShell se cambiaron con el comando Write. Write-Host muestra el texto en pantalla. 
6.- Se elimina el comando set y se coloca el símbolo "$" para declarar la variable $choice. Para presentar las opciones se coloca Read-Host donde
Read es un comando de lectura para el usuario. 
7.- Para un mejor control de las opciones se coloca un switch reemplazando el if y se implementan funciones para controlar mejor las rutas dentro de la historia. 
Además, con la opción default se implementa un mensaje que da opción al usuario de volver a elegir una opción válida y que no aparesca el mensaje de error en el programa.
8.- El comando goto :choice es reemplazado por el nombre de las funciones. 

Toda los comandos se buscaron en la página de powerShell: https://learn.microsoft.com/es-es/powershell/module/microsoft.powershell.core/?view=powershell-7.5