A la hora depoder ejecutar el scrip en Powershell he realizado los siguientes cambios:
1-He cambiado los 'echo' por 'Write-Host'.
2-He agregado funciones a las opciones, ya que sino leía lo que tenía debajo.
3-He agregado condicionales cuando se escogen las opciones, ya que así podremos seleccionar las funciones que queremos que se ejecute en esa opción.
4-Eliminé todos los 'goto'. A la hora de llamar la función no son necesarios.
5-Eliminé todos los colores que había.
6-Para que el usuario pueda escoger una opción numérica agregé un 'Read-Host'.